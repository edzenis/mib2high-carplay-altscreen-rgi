K2161 v8S — v8N small-gauge card placement + command sequencing

Unzip at SD root (the ZIP contains mod/custom.sh).
In M.I.B. use Run custom script. Reboot the MMI manually.
Test routes in Apple Maps, Google Maps, Waze. Switch VIEW repeatedly.
Run custom script again to collect numbered logs.
For rollback create mod/mib2high-carplay-rgi-v8s-simple/ROLLBACK and run custom script again.
Preserve the SD backup/collection directory.

Small gauges (leftAligned): idle safe 360 65 720 367, route safe 132 85 840 332 (v8N).
Big gauges (topAligned): idle/route safe 490 72 460 378 (v8R).
Async showUI -> updateViewArea -> forceKeyFrame, each gated by completion.
Only change maneuver URL when switching gauge slots; supersede stale VIEW events.
No changes to NavIgnore, RGI Java JAR, VC renderer, wheel zoom or video profile.

Status: SOURCE-BUILT, OFFLINE TESTED ONLY. NOT YET CAR-TESTED.
